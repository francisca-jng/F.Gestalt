
# F. Gestalt

A simple landing page for F. Gestalt – architecture, interior design, and Ghana-made products.
