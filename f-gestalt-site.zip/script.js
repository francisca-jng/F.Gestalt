
console.log("F. Gestalt website loaded.");
